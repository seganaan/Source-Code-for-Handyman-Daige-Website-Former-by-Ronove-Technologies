<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true);
define( 'WPCACHEHOME', '/home2/handyma1/public_html/isen.com.ng/wp-content/plugins/wp-super-cache/' );
define( 'DB_NAME', 'handyma1_wp246' );

/** MySQL database username */
define( 'DB_USER', 'handyma1_wp246' );

/** MySQL database password */
define( 'DB_PASSWORD', ')@S280N5pK' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         't5zp5tbrudhf28wlyud1nk2kjy91xxwomi4hoc2bptrvhiojawfu3petgf0scqjl' );
define( 'SECURE_AUTH_KEY',  'teo5lbkvcawzg3cl8fryb48z64xvuq5wfxifxv4xqc0r4ixac47mac540hw2rzs2' );
define( 'LOGGED_IN_KEY',    'tdjnnbqsjamm7ovkadqtw9bm7ls4nnsbr0hyxo7uyk74pdnmqtefg8b8acl1lc08' );
define( 'NONCE_KEY',        '37p8pulqju9cvjdcggpx9bfrcu3uignbc4enxswpw1zxwe51p0qixbvkwjupamci' );
define( 'AUTH_SALT',        'dhiciepjfnjuv1qgkj3fwpmuqkdtin5lk2a5t3mxu5m9lgljcrhuaekfudaezl8n' );
define( 'SECURE_AUTH_SALT', 'rcehxnmeoxyzgzqvuaqgjuvd6lvc0vmptvkn0bxq3sdfxlynymciohgbgpfulsol' );
define( 'LOGGED_IN_SALT',   'l6tm5g8zadkfbqtforsuifolhhstpb44sqedamlksefcecin61q6dzcpuxgqkboj' );
define( 'NONCE_SALT',       'qri9q0f2p9rbwfazsfi6oikvdby5s2op1mpt5yvylgopv2nuwisdbi9sfeyhmaql' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpqy_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
